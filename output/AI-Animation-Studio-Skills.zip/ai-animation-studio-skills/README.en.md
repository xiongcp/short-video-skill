# AI Animation Studio Skills

[简体中文](README.md) · English

An architecture and handoff package for solo creators of **Chinese-language animated explainers**. One entry point organizes research, scripting, voice, storyboards, an original anime host, editable diagrams, reviews and delivery. Two profiles serve **1–3 minute shorts** and **chapter-based programs of about eight minutes**.

**Implementing the studio?** T00 has passed offline acceptance. The next card is T01, environment diagnostics and a 12-second clip with sound. Start with the [agent guide](AGENT.md#en), [handoff status](docs/upgrade/handoff-status.en.md) and [implementation prompt](docs/upgrade/handoff-prompts.en.md).

| What you need | Where to find it |
| --- | --- |
| Scope, milestones and staffing assumptions | [Project plan](docs/upgrade/project-plan.en.md) |
| Architecture, timing, image quality and animation | [Foundation design](docs/architecture.en.md) · [Upgrade design](docs/upgrade/design.en.md) |
| Implement by dependency and record red/green results | [TDD execution plan](docs/upgrade/tdd.en.md) |
| Review a short or a chapter-based program | [Acceptance plan](docs/upgrade/acceptance.en.md) · [Evidence and current status](docs/upgrade/handoff-status.en.md) |
| Give the complete project to another model | [Handoff ZIP on GitHub](https://github.com/xiongcp/short-video-skill/blob/main/output/AI-Animation-Studio-Skills.zip) · [ZIP verification record in the repository](https://github.com/xiongcp/short-video-skill/blob/main/output/交接包复验.json) |
| Read the original Chinese print editions | [Upgrade and acceptance PDF](output/pdf/AI-Animation-Studio-升级实施与验收.pdf) · [Foundation PDF](output/pdf/AI-Animation-Studio-详细设计.pdf) |

## Plan an episode

Download the handoff ZIP above or clone the repository. Run the commands below from the project root.

```sh
git clone https://github.com/xiongcp/short-video-skill.git
cd short-video-skill
```

From the project root, ask your agent to read the [entry skill](skills/topic-to-video/SKILL.md#english). A request can be as simple as “Use this project’s topic-to-video skill to plan a two-minute Chinese animation explaining web caching to beginners. Send the research and script for review first.” Eight-minute requests add chapter budgets, continuity across cuts and recovery checkpoints. Use the same entry point to revise an existing storyboard.

The repository includes readable production instructions, contracts, policies, planning examples and working local validation. Adapter contracts identify their implementation status in `implementation`. The production Studio, original rig and real episodes are tracked in the handoff status. Hosts can load the package through the registry or read individual skill files directly.

| Path | Contents |
| --- | --- |
| [Registry](registry.yaml) and [workflow](workflows/topic-to-video.yaml) | Entry point, 13 skills, nine adapters and approval-aware transitions |
| [Skills](skills/) | Bilingual prerequisites, procedures, inputs, outputs, failures and handoffs in each `SKILL.md` |
| [Profiles](profiles/duration.yaml) and [policies](policies/) | Duration, media specification, permissions, budget, sourcing and G1–G5 |
| [Schemas](schemas/) and [tools](tools/) | JSON Schema Draft 2020-12, adapter requests and results |
| [Two-minute example](examples/topic-cache-speed/) and [eight-minute example](examples/topic-kafka-to-doris/) | Brief, sources, spoken sections, asset plan and complete shot DSL |
| [Evaluation matrix](evals/acceptance.en.md) | Offline structure and semantic checks, negative regressions and production evidence |

## Duration profiles

| Profile | Default and range | Planning example |
| --- | --- | --- |
| `short` | Default 180 seconds. Explicit targets may range from 60 to 180 seconds. | Web caching, 120 s, 14 shots, 3,600 frames |
| `standard8` | Default 480 seconds, design window 450–510 seconds. | Kafka to Doris, 480 s, seven chapters, 34 shots, 14,400 frames |

Both default to 16:9, 1080p, 30 fps and 48 kHz. Runtime includes the opening, pauses, diagram holds and credits. Examples are unapproved plans with audio and art pending. Final episodes require measured duration, QA and human approval.

## Verify locally

Run from the project root with Python 3.9+ and PyYAML, jsonschema and referencing. Install the [listed dependencies](evals/requirements.txt) into a virtual environment if needed.

```sh
python3 -m pip install -r evals/requirements.txt
python3 -B evals/check_design.py
python3 -B -m unittest discover -s evals -p 'test_*.py' -v
```

The architecture checker reads local contracts and examples without model keys. To check a different planning project with the same five JSON files, pass its directory, for example `python3 -B evals/check_design.py examples/topic-kafka-to-doris`.

For all media tests, install FFmpeg and ffprobe with libx264 and AAC encoding. The suite creates and decodes shorts, long programs and deliberately defective fixtures. The first command below replays all six calibration durations. For the second, replace the path with an actual 120-second export.

```sh
python3 -B docs/upgrade/evidence/replay_media.py
python3 -B evals/check_design.py --media renders/final.mp4 --profile short --target-seconds 120
```

## License

The repository carries the [Apache License 2.0](LICENSE). Record the usage rights of any character, voice, font or other asset introduced into a production project.
