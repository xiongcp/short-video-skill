# 仓库代理入口 · Repository instructions

本仓库的代理工作约定、TDD 入口、验收依据和双语维护规则集中在 [AGENT.md](AGENT.md#zh)。在本项目内工作时请先阅读并遵循该文件。

Read and follow the [English project agent guide](AGENT.md#en) before working in this repository. It defines the task entry points, TDD workflow, acceptance evidence and bilingual documentation conventions.
