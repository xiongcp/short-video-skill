# AI Animation Studio Skills

简体中文 · [English](README.en.md)

面向个人创作者的中文知识解说 Skill 架构包。输入主题或已有稿件，通过一个入口组织研究、讲稿、配音、分镜、原创日系角色、程序图解、审核与交付。短片支持 **1–3 分钟**。章节式节目以 **8 分钟**为目标。

**接手工作室开发**时先读[代理指南](AGENT.md#zh)、[交接状态与证据](docs/upgrade/交接状态与证据.md)，再复制[主执行提示词](docs/upgrade/模型交接提示词.md)。T00 已完成，下一张卡是 T01 的环境诊断与 12 秒有声技术片。

| 想做的事 | 项目内入口 |
| --- | --- |
| 确认升级范围、里程碑及资源假设 | [项目计划书](docs/upgrade/项目计划书.md) |
| 理解旧火柴人方案如何迁移到原创动漫主持人 | [升级详细设计](docs/upgrade/升级详细设计.md) · [基础架构详细设计](docs/AI-Animation-Studio-详细设计.md) |
| 按依赖实施，给每次失败、修复和重构留证 | [TDD 执行计划](docs/upgrade/TDD执行计划.md) |
| 独立核对短片和长片的通过条件 | [验收计划](docs/upgrade/验收计划.md) · [离线实测证据](docs/upgrade/交接状态与证据.md) |
| 把完整项目交给另一位模型 | [GitHub 交接包](https://github.com/xiongcp/short-video-skill/blob/main/output/AI-Animation-Studio-Skills.zip) · [仓库中的压缩包复验记录](https://github.com/xiongcp/short-video-skill/blob/main/output/交接包复验.json) |
| 打印阅读或发给审阅人 | [升级实施与验收合订本](output/pdf/AI-Animation-Studio-升级实施与验收.pdf) · [基础架构打印版](output/pdf/AI-Animation-Studio-详细设计.pdf) |

## 策划一期节目

可以使用上方交接包，也可以克隆仓库。下文命令都在项目根目录运行。

```sh
git clone https://github.com/xiongcp/short-video-skill.git
cd short-video-skill
```

在保留完整目录的项目中，让 Agent 读取[主入口 Skill](skills/topic-to-video/SKILL.md)。例如“按本项目的 topic-to-video，做一支 2 分钟的中文动画，给初学者讲网页缓存，先给我研究和讲稿审核材料”。约 8 分钟的请求会采用章节预算、跨章连续性和章节恢复点。已有分镜的返修同样从该入口进入。

当前交付包含可读取的制作指令、合同、策略、示例和离线检查。每个工具目录描述运行时需要实现的适配器。接入状态见工具合同中的 `implementation`。宿主可从注册表装载整个包。在当前仓库内也可以按路径使用入口和各子 Skill。

| 路径 | 内容 |
| --- | --- |
| [registry.yaml](registry.yaml)、[workflows/](workflows/topic-to-video.yaml) | 入口、13 个 Skill、9 个适配器和有审核守卫的状态图 |
| [skills/](skills/) | 13 个能力各有一份双语 SKILL.md，包含前置条件、步骤、输入输出、失败处理和交接 |
| [profiles/](profiles/duration.yaml)、[policies/](policies/) | 片长、媒体规格、工具权限、预算、内容来源与 G1–G5 |
| [schemas/](schemas/)、[tools/](tools/) | JSON Schema Draft 2020-12、工具入参和结果合同 |
| [两分钟样例](examples/topic-cache-speed/)、[八分钟样例](examples/topic-kafka-to-doris/) | 每例均包含主题、来源、逐段讲稿、素材规划和完整逐镜 DSL |
| [evals/](evals/acceptance.md) | 离线结构与语义检查、负向回归和实片验收矩阵 |

## 片长约定

| 档位 | 默认 / 可接受目标 | 规划样例 |
| --- | --- | --- |
| short | 缺省 180 秒，可明确选择 60–180 秒 | 缓存原理，120 秒、14 镜、3,600 帧 |
| standard8 | 缺省 480 秒，设计范围 450–510 秒 | Kafka 到 Doris，480 秒、7 章、34 镜、14,400 帧 |

两档默认使用 16:9、1080p、30 fps、48 kHz。时长已包含开场、停顿、图解与片尾。样例是未审核的制作规划，音频与美术待生产。真实成片按实测时长、QA 和人类审批验收。

## 离线核验

在项目根目录运行。Python 3.9+，依赖为 PyYAML、jsonschema 与 referencing。需要独立环境时可用虚拟环境安装 `evals/requirements.txt`。

```sh
python3 -m pip install -r evals/requirements.txt
python3 -B evals/check_design.py
python3 -B -m unittest discover -s evals -p 'test_*.py' -v
```

检查器读取本地合同和示例，无需模型密钥。也可传入具有相同五份 JSON 文件的规划项目，例如 `python3 -B evals/check_design.py examples/topic-kafka-to-doris`。

在装有 FFmpeg（含 libx264 与 AAC 编码器）和 ffprobe 的环境中，全量测试还会生成并解码短片、长片及故障样本。可用下列命令复现六个校准点，或检查已有的 120 秒成片。后一条命令的文件路径应替换为实际成片。

```sh
python3 -B docs/upgrade/evidence/replay_media.py
python3 -B evals/check_design.py --media renders/final.mp4 --profile short --target-seconds 120
```

## 许可证

仓库沿用 [Apache License 2.0](LICENSE)。在真实制作项目中引入角色、声音、字体等素材时，请分别登记其使用权。
